<center>
<p>NewFanCMS v1 by NotaryzW3b</p>
<p>Copyright 2018.</p>
<p><?PHP echo $sitename; ?> n'est en aucun cas affili&eacute; &agrave; Sulake Corporation et <?PHP echo $serveurfan; ?>
</p>
<a rel="license" href="http://creativecommons.org/licenses/by-nd/4.0/"><img alt="Licence Creative Commons" style="border-width:0" src="https://i.creativecommons.org/l/by-nd/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Dataset" property="dct:title" rel="dct:type">NewFanCMS</span> de <a xmlns:cc="http://creativecommons.org/ns#" href="https://github.com/notaryzw3b" property="cc:attributionName" rel="cc:attributionURL">NotaryzW3b</a> est mis &agrave; disposition selon les termes de la <a rel="license" href="http://creativecommons.org/licenses/by-nd/4.0/">licence Creative Commons Attribution - Pas de Modification 4.0 International</a>.<br />Fond&eacute;(e) sur une &oelig;uvre &agrave; <a xmlns:dct="http://purl.org/dc/terms/" href="https://github.com/notaryzw3b/newfancms" rel="dct:source">https://github.com/notaryzw3b/newfancms</a>.
</center>