<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<body>
<link type="text/css" href="general.css" rel="stylesheet" />
<script type="text/javascript" src="ajax.js"></script>
<body>
<div id="nav">
  <a href="javascript:ajaxpage('header/nav.html',%20'subnav');"><div class="menu">Accueil</div></a>
  <a href="javascript:ajaxpage('header/nav1.html',%20'subnav');"><div class="menu">Communaut&eacute;</div></a>
  <a href="javascript:ajaxpage('header/nav2.html',%20'subnav');"><div class="menu">Extras</div></a>
  <a href="javascript:ajaxpage('header/nav3.html',%20'subnav');"><div class="menu">Guide</div></a>
  <a href="javascript:ajaxpage('header/nav4.html',%20'subnav');"><div class="menu">Forum BETA</div></a>
</div>
</body>
</html>