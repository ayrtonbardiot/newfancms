<?PHP
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|         NewFanCMS - CMS pour Fansite Habbo.                            #|
#|         Copyright � 2018 NotaryzW3b. Tout droits r�serv�s              #|
#|	       CMS bas� sur la template d'EkizDesign n*12                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|

include('config/config.php');
$pagename = "Accueil"

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link type="text/css" href="general.css" rel="stylesheet" />
<script type="text/javascript" src="ajax.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?PHP echo $sitename; ?> : <?PHP echo $pagename; ?></title>
<style type="text/css">
<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
</style></head>

<body>
<div id="nav">
<?PHP include('header.php'); ?>
</div>
<div id="subnav"></div>
<div id="banner_space"><div id="banner"></div></div>
<div id="bar"></div>
<div id="cont_up"></div>
<div id="cont_mid">
<div id="box_large">
<div id="grey"><strong>Title</strong></div>
<div id="mid_large">Hello xD</div>
</div>
<div id="box_small">
<div id="yellow"><strong>Title</strong></div>
<div id="mid_small">Hello xD</div>
<div id="orange"><strong>Title</strong></div>
<div id="mid_small">Hello xD</div>
</div>
</div>
<div id="cont_bottom"></div>
<?PHP 
include ('footer.php');
?>
</body>
</html>