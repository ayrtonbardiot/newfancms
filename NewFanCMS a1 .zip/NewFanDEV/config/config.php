<?PHP
define('DIRECT', TRUE);
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
#|                                                                        #|
#|         NewFanCMS - CMS pour Fansite Habbo.                            #|
#|         Copyright © 2018 NotaryzW3b. Tout droits réservés              #|
#|	       CMS basé sur la template d'EkizDesign n*12                     #|
#|                                                                        #|
#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|#|
if (!defined('DIRECT'))
{
	die('Tu fais quoi ici mon khey?');
}
setcookie('CMS', 'NewFanCMS', time() + 365*24*3600, null, null, false, true);
setcookie('VERSION', 'V1', time() + 365*24*3600, null, null, false, true);
$sitename = "NewFanDEV"; #NOM DU SITE
$siteurl = "http://localhost/Dev/NewFanDEV/"; #LIEN DU SITE
$createur = "NotaryzW3b"; #NOM DU CREATEUR DU !FANSITE!
$serveurfan = "HabbGameur"; #NOM DU SITE AUQUEL VOUS ETES FAN#

?>
